from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User

def auth_view(request):
    mode = request.GET.get("mode", "login")

    # --- Handle LOGIN ---
    if request.method == "POST" and mode == "login":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)

            # Redirect based on role
            if user.is_staff or user.is_superuser:
                return redirect("dashboards:admin_dashboard")
            else:
                return redirect("dashboards:user_dashboard")
        else:
            messages.error(request, "Invalid username or password.")

    # --- Handle SIGNUP ---
    elif request.method == "POST" and mode == "signup":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password1 = request.POST.get("password1")
        password2 = request.POST.get("password2")

        if password1 != password2:
            messages.error(request, "Passwords do not match.")
        elif User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password1)
            user.save()
            messages.success(request, "Account created successfully! You can now log in.")
            return redirect("/users/auth/?mode=login")

    return render(request, "users/auth.html", {"mode": mode})


def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("/users/auth/?mode=login")
