from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(
    required=True,
    widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter your email'}))


first_name = forms.CharField(
required=False,
widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First name'})
)


last_name = forms.CharField(
required=False,
widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last name'})
)


class Meta:
    model = User
    fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']


def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
    self.fields['username'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Choose a username'})
    self.fields['password1'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Create password'})
    self.fields['password2'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Confirm password'})