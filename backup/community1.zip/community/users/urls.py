from django.urls import path
from .views import auth_view, logout_view

app_name = 'users'

urlpatterns = [
    path('auth/', auth_view, name='auth'),
    path('logout/', logout_view, name='logout'),
]

# Include multi-user functionality
from . import urls_multiuser
urlpatterns += urls_multiuser.urlpatterns
