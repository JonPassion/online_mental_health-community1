from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class UserPresence(models.Model):
    """Track user online status and last activity"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='presence')
    is_online = models.BooleanField(default=False)
    last_seen = models.DateTimeField(auto_now=True)
    last_activity = models.DateTimeField(auto_now=True)
    current_room = models.ForeignKey('chat.ChatRoom', on_delete=models.SET_NULL, null=True, blank=True)
    
    class Meta:
        verbose_name = "User Presence"
        verbose_name_plural = "User Presences"
    
    def __str__(self):
        return f"{self.user.username} - {'Online' if self.is_online else 'Offline'}"
    
    @classmethod
    def update_activity(cls, user, room=None):
        """Update user's last activity and current room"""
        presence, created = cls.objects.get_or_create(user=user)
        presence.is_online = True
        presence.last_activity = timezone.now()
        if room:
            presence.current_room = room
        presence.save()
        return presence
    
    @classmethod
    def mark_offline(cls, user):
        """Mark user as offline"""
        presence, created = cls.objects.get_or_create(user=user)
        presence.is_online = False
        presence.current_room = None
        presence.save()


class UserActivity(models.Model):
    """Log user activities for tracking"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='activities')
    activity_type = models.CharField(max_length=50)  # 'message_sent', 'post_created', 'login', etc.
    description = models.TextField(blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    related_object_id = models.PositiveIntegerField(null=True, blank=True)
    related_object_type = models.CharField(max_length=50, blank=True)
    
    class Meta:
        verbose_name = "User Activity"
        verbose_name_plural = "User Activities"
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.user.username} - {self.activity_type} at {self.timestamp.strftime('%H:%M')}"


class Notification(models.Model):
    """Real-time notifications for users"""
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_notifications', null=True, blank=True)
    notification_type = models.CharField(max_length=50)  # 'new_message', 'new_post', 'mention', etc.
    title = models.CharField(max_length=200)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    related_object_id = models.PositiveIntegerField(null=True, blank=True)
    related_object_type = models.CharField(max_length=50, blank=True)
    
    class Meta:
        verbose_name = "Notification"
        verbose_name_plural = "Notifications"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.recipient.username} - {self.title}"
