from django.shortcuts import render, redirect, get_object_or_404
from .models import ChatRoom, Message
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.db import models
from users.models import UserPresence, UserActivity, Notification


def has_room_access(user, room):
    """Check if user has access to a chat room"""
    # Room creator always has access
    if room.user == user:
        return True
    
    # Check if it's a direct message room involving this user
    if room.name.startswith('DM_'):
        try:
            user_ids = room.name.split('_')[1:]  # Skip 'DM_' prefix
            return str(user.id) in user_ids
        except:
            return False
    
    # For now, allow access to all rooms (you can customize this logic)
    # Later you can add room membership checks here
    return True
# Create your views here.

@login_required
def room_list(request):
    rooms = ChatRoom.objects.all()
    return render(request, 'chat/room_list.html', {'rooms': rooms})


@login_required
def room(request, room_name):
    return render(request, 'chat/room.html', {
        'room_name': room_name,
        'username': request.user.username if request.user.is_authenticated else 'Guest'
    })



@login_required
def chat_index(request):
    rooms = ChatRoom.objects.all()
    return render(request, "chat/chat_index.html", {"rooms": rooms})

@login_required
def chatting(request, room_id):
    room = get_object_or_404(ChatRoom, id=room_id)
    rooms = ChatRoom.objects.all()  # sidebar
    return render(request, "chat/chats_mini.html", {"room": room, "rooms": rooms})

@login_required
def send_message(request):
    if request.method == "POST":
        room_id = request.POST.get("room_id")
        content = request.POST.get("message")
        room = get_object_or_404(ChatRoom, id=room_id)
        
        # Check if user has access to this room
        if not has_room_access(request.user, room):
            return JsonResponse({"error": "Access denied"}, status=403)
        
        # Create message
        message = Message.objects.create(
            room=room,
            user=request.user,
            content=content,
            timestamp=timezone.now()
        )
        
        # Update user presence and activity
        UserPresence.update_activity(request.user, room)
        UserActivity.objects.create(
            user=request.user,
            activity_type='message_sent',
            description=f'Sent message in {room.name}',
            related_object_id=message.id,
            related_object_type='message'
        )
        
        # Create notifications for other users in the room
        room_users = Message.objects.filter(room=room).values_list('user', flat=True).distinct()
        for user_id in room_users:
            if user_id != request.user.id:
                # Only notify users who have access to this room
                other_user = User.objects.get(id=user_id)
                if has_room_access(other_user, room):
                    Notification.objects.create(
                        recipient=other_user,
                        sender=request.user,
                        notification_type='new_message',
                        title=f'New message in {room.name}',
                        message=f'{request.user.username}: {content[:50]}...',
                        related_object_id=message.id,
                        related_object_type='message'
                    )
        
        return JsonResponse({
            "id": message.id,
            "user": message.user.username,
            "user_id": message.user.id,
            "content": message.content,
            "sent_by_me": message.user == request.user,
            "timestamp": message.timestamp.isoformat()
        })
    return JsonResponse({"error": "Invalid request"}, status=400)

@login_required
def chat_dashboard(request):
    """Render the chat dashboard template with real users and rooms"""
    # Get all users except current user for contacts
    all_users = User.objects.exclude(id=request.user.id)
    
    # Get all chat rooms
    rooms = ChatRoom.objects.all()
    
    return render(request, 'chat_dash/chadashboard.html', {
        'all_users': all_users,
        'rooms': rooms
    })

@login_required
def get_users(request):
    """API endpoint to get all users (except current user)"""
    users = User.objects.exclude(id=request.user.id).values('id', 'username', 'email')
    return JsonResponse(list(users), safe=False)

@login_required
def create_direct_room(request):
    """Create or get a direct message room between two users"""
    if request.method == "POST":
        user_id = request.POST.get("user_id")
        other_user = get_object_or_404(User, id=user_id)
        
        # Look for existing room between these users
        room_name = f"DM_{request.user.id}_{other_user.id}"
        reverse_room_name = f"DM_{other_user.id}_{request.user.id}"
        
        room = ChatRoom.objects.filter(
            models.Q(name=room_name) | models.Q(name=reverse_room_name)
        ).first()
        
        if not room:
            # Create new direct message room
            room = ChatRoom.objects.create(
                name=room_name,
                user=request.user
            )
        
        return JsonResponse({"room_id": room.id})
    
    return JsonResponse({"error": "Invalid request"}, status=400)

@login_required
def get_chat_rooms(request):
    """API endpoint to get all chat rooms"""
    rooms = ChatRoom.objects.all().values('id', 'name')
    return JsonResponse(list(rooms), safe=False)

@login_required
def get_messages(request, room_id):
    room = get_object_or_404(ChatRoom, id=room_id)
    
    # Check if user has access to this room
    if not has_room_access(request.user, room):
        return JsonResponse({"error": "Access denied"}, status=403)
    
    messages = Message.objects.filter(room=room).order_by("timestamp")
    messages_data = [
        {
            "id": m.id,
            "user": m.user.username,
            "user_id": m.user.id,
            "content": m.content,
            "sent_by_me": m.user == request.user,
            "timestamp": m.timestamp.isoformat()
        } for m in messages
    ]
    return JsonResponse(messages_data, safe=False)