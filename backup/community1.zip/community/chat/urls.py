from django.urls import path
from . import views
from . import mini

app_name = "chat"

urlpatterns = [
    # General chat pages
    path('', views.chat_index, name='index'),
    path('room_list/', views.room_list, name='room_list'),
    path('dashboard/', views.chat_dashboard, name='dashboard'),

    # API endpoints
    path('api/users/', views.get_users, name='get_users'),
    path('api/rooms/', views.get_chat_rooms, name='get_chat_rooms'),
    path('chat/create-direct-room/', views.create_direct_room, name='create_direct_room'),

    # Specific chat room by name (string)
    path('room/<str:room_name>/', views.room, name='room'),

    path('', views.chat_index, name='index'),
    path('chat/<int:room_id>/', views.chatting, name='chatting'),
    path('chat/send/', views.send_message, name='send_message'),
    path('chat/messages/<int:room_id>/', views.get_messages, name='get_messages'),

    # Dashboard mini apps
    path('mini_chats/', mini.mini_chats, name='mini_chats'),
    path('miniposts/', mini.miniposts, name='miniposts'),
]